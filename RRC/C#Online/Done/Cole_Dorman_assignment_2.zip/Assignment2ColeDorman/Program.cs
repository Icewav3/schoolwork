﻿using System;
using System.Runtime;
using System.Collections.Generic;
using Dorman.Cole.Business;


namespace RRCAGAppColeDorman
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("testing instantiating a service invoice\n");
            ServiceInvoice ServiceInvoice1 = new ServiceInvoice(0.1m, 0.2m);
            Console.WriteLine("test 1\nExpected: 0.1");
            Console.WriteLine("Actual: " + ServiceInvoice1.ProvincialSalesTaxRate + "\n");
            Console.WriteLine("test 2\nExpected: 0.2");
            Console.WriteLine("Actual: " + ServiceInvoice1.GoodsAndServicesTaxRate + "\n");

            Console.WriteLine("testing adding costs\n");
            ServiceInvoice1.AddCost(ServiceInvoice.CostType.Labour, 100);
            ServiceInvoice1.AddCost(ServiceInvoice.CostType.Material, 300);
            ServiceInvoice1.AddCost(ServiceInvoice.CostType.Part, 50);
            Console.WriteLine("test labour cost\nExpected: 100");
            Console.WriteLine("Actual: " + ServiceInvoice1.LabourCost + "\n");
            Console.WriteLine("test material cost\nExpected: 300");
            Console.WriteLine("Actual: " + ServiceInvoice1.MaterialsCost + "\n");
            Console.WriteLine("test part cost\nExpected: 50");
            Console.WriteLine("Actual: " + ServiceInvoice1.PartsCost + "\n");
            Console.WriteLine("test subtotal\nExpected: 450");
            Console.WriteLine("Actual: " + ServiceInvoice1.Subtotal + "\n");
            Console.WriteLine("test total\nExpected: 575");
            Console.WriteLine("Actual: " + ServiceInvoice1.Total + "\n");

            Console.WriteLine("\nService Invoice testing complete\n");
            Console.WriteLine("testing instantiating a car wash invoice\n");
            CarWashInvoice CarWashInvoice1 = new CarWashInvoice(0.25m, 0.7m, 200m, 300m);
            Console.WriteLine("test 1\nExpected: 0.25");
            Console.WriteLine("Actual: " + CarWashInvoice1.ProvincialSalesTaxRate + "\n");
            Console.WriteLine("test 2\nExpected: 0.7");
            Console.WriteLine("Actual: " + CarWashInvoice1.GoodsAndServicesTaxRate + "\n");
            Console.WriteLine("test 3\nExpected: 200");
            Console.WriteLine("Actual: " + CarWashInvoice1.PackageCost + "\n");
            Console.WriteLine("test subtotal\nExpected: 500");
            Console.WriteLine("Actual: " + CarWashInvoice1.Subtotal + "\n");
            Console.WriteLine("test total\nExpected: 925");
            Console.WriteLine("Actual: " + CarWashInvoice1.Total + "\n");
            CarWashInvoice1.PackageCost = 150.0m;
            Console.WriteLine("test change packageCost\nExpected: 150");
            Console.WriteLine("Actual: " + CarWashInvoice1.PackageCost + "\n");
            CarWashInvoice1.FragranceCost = 774.0m;
            Console.WriteLine("test change FragranceCost\nExpected: 774");
            Console.WriteLine("Actual: " + CarWashInvoice1.FragranceCost + "\n");
            Console.WriteLine("test change GetPayment of carwashinvoice1 total\nExpected: 208.37");
            Console.WriteLine("Actual: " + Financial.GetPayment(0.2m, 12, 925) + "\n");

            Console.ReadKey();
        }
    }
}
