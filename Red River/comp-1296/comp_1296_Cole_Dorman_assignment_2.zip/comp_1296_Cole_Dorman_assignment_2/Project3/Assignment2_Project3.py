# -*- coding: utf-8 -*-
"""
Created on Tue Sep 26 11:28:45 2023

@author: coled
"""

#Project 3
#Declarations
string1 = "Monday"
string2 = "Tuesday"
float1 = -17.45
int1 = 3

print(f"The original data type of float variable {float1} was: "+str(type(float1)))

casted_float = int(float1)

print(f"The new data type of this variable {casted_float} is: "+str(type(casted_float)))