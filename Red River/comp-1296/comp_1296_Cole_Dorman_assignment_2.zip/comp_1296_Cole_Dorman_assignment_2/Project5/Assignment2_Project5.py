# -*- coding: utf-8 -*-
"""
Created on Wed Sep 27 12:51:37 2023

@author: coled
"""
electronics_list = ["AAA Battery", "Phone Charger"]
food_list = ["Frozen Pizza", "Bananas"]
hardware_list = ["Drill", "Hammer"]
kitchen_list = ["Cooking pot", "Dish towel"]
pets_list = ["Dog food", "Catnip"]

catagories = ["Food", "Electronics", "Hardware", "Kitchen", "Pets"]
store_inventory_dictionary = {"Food":food_list, "Electronics":electronics_list, "Hardware":hardware_list, "Kitchen":kitchen_list, "Pets":pets_list}

print(f"The entire Dictionary is: {store_inventory_dictionary}\n")
for i in catagories:
    current = i
    print("The category "+str(current)+" contains: "+str(store_inventory_dictionary[current])+"\n")