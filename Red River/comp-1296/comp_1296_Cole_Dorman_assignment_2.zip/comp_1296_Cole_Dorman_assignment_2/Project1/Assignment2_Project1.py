# -*- coding: utf-8 -*-
"""
Created on Tue Sep 26 10:17:04 2023

@author: coled
"""

#Project 1
#Declarations
string1 = "Monday"
string2 = "Tuesday"
float1 = -17.45
int1 = 3

print(f"The first String variable is {string1}.")
print(f"The second String variable is {string2}.")
print(f"The float variable is {float1}.")
print(f"The integer variable is {int1}.")