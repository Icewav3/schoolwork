# -*- coding: utf-8 -*-
"""
Created on Tue Sep 26 10:36:27 2023

@author: coled
"""
#Project 2
#Declarations
string1 = "Monday"
string2 = "Tuesday"
float1 = -17.45
int1 = 3

print(f"The temperature on {string1} was {float1}")
print(f"The temperature on {string2} was {int1}")