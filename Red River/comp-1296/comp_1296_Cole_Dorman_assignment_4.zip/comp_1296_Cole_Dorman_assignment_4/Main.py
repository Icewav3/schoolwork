import Tuition_Calculator
print("\n~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n")
import User_Profile_Generator

#Tuition_Calculator
#User_Profile_Generator