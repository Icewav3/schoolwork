class Util:
    def __init__(self):
        pass
    def clean(self, string):
        return string.lower().strip()
